
//[ Starting of count function
function counterBtn(e,f){
    var count=document.getElementById(f).innerHTML
    if(count>=1){
        if(e==='+'){
            count++
            document.getElementById(f).innerHTML=count
            
        }
        else{
            count--
            if(count=== 0){
                count++
            document.getElementById(f).innerHTML=count
            }
            else{
                document.getElementById(f).innerHTML=count
            }
        }
            
    }
    
}

//End of count Function]



var tableContent=document.getElementById('table2')


function addtoCard(e){

    //[ Get all inner child inner html with parent node id e

    var content=document.getElementById(e)
    var h5=content.getElementsByTagName('h5')[0].innerHTML
    var price=content.getElementsByTagName('p')[0].getElementsByTagName('span')[0].innerHTML
    var Quantity=content.getElementsByClassName('td1')[0].innerHTML 
    //end

    // calculate total price of each item
    var totalPrice =Quantity*price
    var totalpricInt=parseInt(totalPrice)   

    //calculate total price
    var total=document.getElementById('total').innerHTML
    var totalInt=parseInt(total)
    totalInt=totalInt+totalpricInt
    
    
    
    
    
    // create td and append all value in td
    
    var Quantity1=document.createElement('td')
    var QuantityText=document.createTextNode(Quantity)
    Quantity1.appendChild(QuantityText)

    var h51=document.createElement('td')
    var h51Text=document.createTextNode(h5)
    h51.appendChild(h51Text)

    var price1=document.createElement('td')
    var price1Text=document.createTextNode(price)
    price1.appendChild(price1Text)

    var totalPrice1=document.createElement('td')
    totalPrice1.appendChild(document.createTextNode(totalPrice))

    var delbtn=document.createElement('button')
    delbtn.appendChild(document.createTextNode("X"))
    delbtn.setAttribute('onclick','del_element(this)')
    delbtn.setAttribute('class','delbtn gh')

    


    
     // create tr and append all value in tr

    var trContent=document.createElement('tr')

    trContent.appendChild(h51)
    trContent.appendChild(Quantity1)
    trContent.appendChild(price1)
    trContent.appendChild(totalPrice1)
    trContent.appendChild(delbtn)
    
    //append all tr in a table
    tableContent.appendChild(trContent)
    
    // insert total
    document.getElementById('total').innerHTML=totalInt


}

//table delete function

function del_element(d){
    var rem=d.parentNode
    var na =rem.getElementsByTagName('td')
    
    var total=document.getElementById('total').innerHTML
    var totalInt=parseInt(total)
     var na1=parseInt(na[3].innerHTML)
     
    

    
    document.getElementById('total').innerHTML=totalInt-na1

    d.parentNode.remove()
    
}